package my.example.theatre;

public class SessionsAdapter {
}
