package my.example.theatre;

public class CinemasAdapter {
}
